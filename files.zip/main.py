"""
main.py
-------
The entry point for the Library Management System.
Provides a simple menu-driven Command Line Interface (CLI)
so a user can interact with the system without needing to
write any code themselves.

Run with: python main.py
"""

from database import initialize_database
from library import Library


def print_menu():
    print("\n========== LIBRARY MANAGEMENT SYSTEM ==========")
    print("1.  Add Book")
    print("2.  Remove Book")
    print("3.  Search Book")
    print("4.  List All Books")
    print("5.  Register Member")
    print("6.  Remove Member")
    print("7.  List All Members")
    print("8.  Issue Book")
    print("9.  Return Book")
    print("10. View Currently Issued Books")
    print("11. View Overdue Books")
    print("0.  Exit")
    print("=================================================")


def main():
    initialize_database()
    library = Library()

    while True:
        print_menu()
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            title = input("Title: ").strip()
            author = input("Author: ").strip()
            isbn = input("ISBN: ").strip()
            copies = int(input("Number of copies: ").strip())
            print(library.add_book(title, author, isbn, copies))

        elif choice == "2":
            isbn = input("Enter ISBN of book to remove: ").strip()
            print(library.remove_book(isbn))

        elif choice == "3":
            keyword = input("Enter title/author/ISBN to search: ").strip()
            results = library.search_books(keyword)
            if not results:
                print("No matching books found.")
            else:
                for book in results:
                    print(book)

        elif choice == "4":
            books = library.list_books()
            if not books:
                print("No books in the library yet.")
            for book in books:
                print(book)

        elif choice == "5":
            name = input("Member name: ").strip()
            email = input("Email: ").strip()
            phone = input("Phone: ").strip()
            print(library.add_member(name, email, phone))

        elif choice == "6":
            member_id = int(input("Enter member ID to remove: ").strip())
            print(library.remove_member(member_id))

        elif choice == "7":
            members = library.list_members()
            if not members:
                print("No members registered yet.")
            for member in members:
                print(member)

        elif choice == "8":
            isbn = input("ISBN of book to issue: ").strip()
            member_id = int(input("Member ID: ").strip())
            print(library.issue_book(isbn, member_id))

        elif choice == "9":
            isbn = input("ISBN of book to return: ").strip()
            member_id = int(input("Member ID: ").strip())
            print(library.return_book(isbn, member_id))

        elif choice == "10":
            issued = library.list_issued_books()
            if not issued:
                print("No books are currently issued.")
            for row in issued:
                print(f"Txn#{row['id']} | '{row['title']}' -> {row['member_name']} "
                      f"| Issued: {row['issue_date']} | Due: {row['due_date']}")

        elif choice == "11":
            overdue = library.list_overdue_books()
            if not overdue:
                print("No overdue books. Everything is on time.")
            for row in overdue:
                print(f"Txn#{row['id']} | '{row['title']}' -> {row['member_name']} "
                      f"| Was due: {row['due_date']}")

        elif choice == "0":
            print("Exiting... Thank you for using the Library Management System.")
            library.close()
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
