# Library Management System

A command-line Library Management System built in Python using SQLite
for persistent storage. Demonstrates Object-Oriented Programming, database
design (CRUD operations), and real-world business logic (due dates and
fine calculation).

---

## Features

- **Book Management**: Add books (with multiple copies), remove books, search by title/author/ISBN, list all books.
- **Member Management**: Register members, remove members, list all members.
- **Issue / Return System**:
  - A book can only be issued if at least one copy is available.
  - Each issue creates a 14-day loan period with an automatic due date.
  - Returning late automatically calculates a fine (Rs. 5/day).
- **Reports**: View currently issued books, view overdue books.

---

## Project Structure

```
library_management_system/
├── database.py    # SQLite connection + schema (table) setup
├── models.py      # Book and Member classes (data representation)
├── library.py      # Library class - all business logic (the "engine")
├── main.py        # CLI menu - the entry point users interact with
└── README.md
```

**Why split into multiple files?**
This follows separation of concerns:
- `database.py` only knows how to connect to and set up the DB.
- `models.py` only knows how to represent a Book/Member as an object.
- `library.py` contains all the actual rules of the system (the logic).
- `main.py` only handles user interaction (input/output).

If you wanted to swap the CLI for a web interface later (e.g. Flask),
you would only need to change `main.py` — the database and business logic
stay exactly the same. This is a point worth mentioning in interviews.

---

## How to Run

1. Make sure you have Python 3.8+ installed (no external libraries needed —
   `sqlite3` is built into Python's standard library).
2. Open a terminal in the project folder.
3. Run:
   ```
   python main.py
   ```
4. A `library.db` file will be created automatically the first time you run it.
5. Follow the on-screen menu to add books, register members, issue/return books, etc.

---

## Database Schema

**books**
| Column | Type | Notes |
|---|---|---|
| id | INTEGER (PK) | Auto-incremented |
| title | TEXT | |
| author | TEXT | |
| isbn | TEXT (UNIQUE) | Used to identify a book uniquely |
| total_copies | INTEGER | Total copies owned by the library |
| available_copies | INTEGER | Copies currently not issued |

**members**
| Column | Type | Notes |
|---|---|---|
| id | INTEGER (PK) | Auto-incremented |
| name | TEXT | |
| email | TEXT (UNIQUE) | |
| phone | TEXT | |
| membership_date | TEXT | Date registered |

**transactions**
| Column | Type | Notes |
|---|---|---|
| id | INTEGER (PK) | Auto-incremented |
| book_id | INTEGER (FK) | References books.id |
| member_id | INTEGER (FK) | References members.id |
| issue_date | TEXT | |
| due_date | TEXT | issue_date + 14 days |
| return_date | TEXT | NULL until the book is returned |
| fine | REAL | Calculated only if returned late |

The `transactions` table is the key design decision here — instead of
just tracking "who has which book" in a single mutable field, every
issue/return event is recorded as a row. This means the system keeps
a full history, and overdue/fine logic can be derived just by comparing
dates, rather than needing extra status flags.

---

## Business Rules

- **Loan period**: 14 days from the date of issue.
- **Fine**: Rs. 5 per day late (calculated only when the book is returned, based on the difference between `due_date` and the actual return date).
- A book cannot be issued if `available_copies` is 0.
- Adding a book with an ISBN that already exists increases the copy count instead of creating a duplicate entry — this avoids duplicate book records for the same title.

---

## Possible Extensions (good talking points for "what would you improve?")

- Add a reservation/waitlist system for books that are fully issued.
- Email/SMS reminders before the due date.
- A simple Flask web UI on top of the same `library.py` logic.
- Admin login / authentication for staff-only operations (add/remove books).
- Export reports (issued books, overdue books) to CSV or PDF.
- Pagination for `list_books()` / `list_members()` once the dataset grows large.

---

## Tech Stack

- **Language**: Python 3
- **Database**: SQLite3 (via Python's built-in `sqlite3` module)
- **Concepts used**: Object-Oriented Programming (classes for Book, Member, Library), CRUD operations, datetime handling, SQL joins, parameterized queries (to prevent SQL injection)
