"""
library.py
-----------
The Library class is the heart of the system. It contains all
the business logic: adding/searching books, registering members,
issuing/returning books, and calculating fines.

Design notes for interview discussion:
- Loan period: 14 days from the issue date.
- Fine: Rs. 5 per day for every day late beyond the due date.
- A book can only be issued if `available_copies > 0`.
- Returning a book increases `available_copies` back by 1.
"""

from datetime import datetime, timedelta
from database import get_connection
from models import Book, Member

LOAN_PERIOD_DAYS = 14
FINE_PER_DAY = 5


class Library:
    def __init__(self):
        self.conn = get_connection()

    # ---------- BOOK OPERATIONS ----------

    def add_book(self, title, author, isbn, total_copies):
        """Add a new book, or increase copies if the ISBN already exists."""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM books WHERE isbn = ?", (isbn,))
        existing = cursor.fetchone()

        if existing:
            new_total = existing["total_copies"] + total_copies
            new_available = existing["available_copies"] + total_copies
            cursor.execute(
                "UPDATE books SET total_copies = ?, available_copies = ? WHERE isbn = ?",
                (new_total, new_available, isbn)
            )
            self.conn.commit()
            return f"Added {total_copies} more copies of '{title}'. New total: {new_total}"
        else:
            cursor.execute(
                "INSERT INTO books (title, author, isbn, total_copies, available_copies) "
                "VALUES (?, ?, ?, ?, ?)",
                (title, author, isbn, total_copies, total_copies)
            )
            self.conn.commit()
            return f"Book '{title}' added successfully."

    def remove_book(self, isbn):
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM books WHERE isbn = ?", (isbn,))
        self.conn.commit()
        if cursor.rowcount == 0:
            return "No book found with that ISBN."
        return "Book removed successfully."

    def search_books(self, keyword):
        """Search by title, author, or ISBN (partial match, case-insensitive)."""
        cursor = self.conn.cursor()
        like_term = f"%{keyword}%"
        cursor.execute(
            "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ?",
            (like_term, like_term, like_term)
        )
        rows = cursor.fetchall()
        return [Book(**row) for row in rows]

    def list_books(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM books ORDER BY title")
        return [Book(**row) for row in cursor.fetchall()]

    # ---------- MEMBER OPERATIONS ----------

    def add_member(self, name, email, phone):
        cursor = self.conn.cursor()
        membership_date = datetime.now().strftime("%Y-%m-%d")
        try:
            cursor.execute(
                "INSERT INTO members (name, email, phone, membership_date) VALUES (?, ?, ?, ?)",
                (name, email, phone, membership_date)
            )
            self.conn.commit()
            return f"Member '{name}' registered successfully."
        except Exception:
            return "A member with this email already exists."

    def remove_member(self, member_id):
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM members WHERE id = ?", (member_id,))
        self.conn.commit()
        if cursor.rowcount == 0:
            return "No member found with that ID."
        return "Member removed successfully."

    def list_members(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM members ORDER BY name")
        return [Member(**row) for row in cursor.fetchall()]

    # ---------- ISSUE / RETURN LOGIC ----------

    def issue_book(self, isbn, member_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM books WHERE isbn = ?", (isbn,))
        book = cursor.fetchone()

        if not book:
            return "Book not found."
        if book["available_copies"] <= 0:
            return f"'{book['title']}' is currently unavailable (all copies issued)."

        cursor.execute("SELECT * FROM members WHERE id = ?", (member_id,))
        member = cursor.fetchone()
        if not member:
            return "Member not found."

        issue_date = datetime.now()
        due_date = issue_date + timedelta(days=LOAN_PERIOD_DAYS)

        cursor.execute(
            "INSERT INTO transactions (book_id, member_id, issue_date, due_date) "
            "VALUES (?, ?, ?, ?)",
            (book["id"], member_id, issue_date.strftime("%Y-%m-%d"), due_date.strftime("%Y-%m-%d"))
        )
        cursor.execute(
            "UPDATE books SET available_copies = available_copies - 1 WHERE id = ?",
            (book["id"],)
        )
        self.conn.commit()
        return (f"'{book['title']}' issued to {member['name']}. "
                f"Due back by {due_date.strftime('%Y-%m-%d')}.")

    def return_book(self, isbn, member_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM books WHERE isbn = ?", (isbn,))
        book = cursor.fetchone()
        if not book:
            return "Book not found."

        # Find the open transaction (not yet returned) for this book + member
        cursor.execute(
            "SELECT * FROM transactions WHERE book_id = ? AND member_id = ? AND return_date IS NULL",
            (book["id"], member_id)
        )
        txn = cursor.fetchone()
        if not txn:
            return "No active issue record found for this book and member."

        return_date = datetime.now()
        due_date = datetime.strptime(txn["due_date"], "%Y-%m-%d")

        fine = 0
        days_late = 0
        if return_date.date() > due_date.date():
            days_late = (return_date.date() - due_date.date()).days
            fine = days_late * FINE_PER_DAY

        cursor.execute(
            "UPDATE transactions SET return_date = ?, fine = ? WHERE id = ?",
            (return_date.strftime("%Y-%m-%d"), fine, txn["id"])
        )
        cursor.execute(
            "UPDATE books SET available_copies = available_copies + 1 WHERE id = ?",
            (book["id"],)
        )
        self.conn.commit()

        if fine > 0:
            return f"Book returned. Fine due: Rs. {fine} ({days_late} day(s) late)."
        return "Book returned on time. No fine."

    # ---------- REPORTS ----------

    def list_issued_books(self):
        """All books currently checked out (not yet returned)."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT t.id, b.title, m.name AS member_name, t.issue_date, t.due_date
            FROM transactions t
            JOIN books b ON t.book_id = b.id
            JOIN members m ON t.member_id = m.id
            WHERE t.return_date IS NULL
            ORDER BY t.due_date
        """)
        return cursor.fetchall()

    def list_overdue_books(self):
        """Books that are still out and past their due date."""
        today = datetime.now().strftime("%Y-%m-%d")
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT t.id, b.title, m.name AS member_name, t.due_date
            FROM transactions t
            JOIN books b ON t.book_id = b.id
            JOIN members m ON t.member_id = m.id
            WHERE t.return_date IS NULL AND t.due_date < ?
            ORDER BY t.due_date
        """, (today,))
        return cursor.fetchall()

    def close(self):
        self.conn.close()
