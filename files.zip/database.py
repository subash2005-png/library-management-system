"""
database.py
------------
Handles the SQLite database connection and schema creation
for the Library Management System.

Why SQLite?
- Lightweight, file-based, no separate server needed.
- Built into Python's standard library (no extra installs).
- Good fit for a small-to-medium scale application like this one.
"""

import sqlite3
import os

DB_NAME = os.path.join(os.path.dirname(__file__), "library.db")


def get_connection():
    """
    Returns a connection to the SQLite database.
    `check_same_thread=False` allows the connection to be reused
    safely within this single-process CLI app.
    """
    conn = sqlite3.connect(DB_NAME, check_same_thread=False)
    conn.row_factory = sqlite3.Row  # lets us access columns by name, like a dict
    return conn


def initialize_database():
    """
    Creates the required tables if they do not already exist.
    Called once when the application starts.
    """
    conn = get_connection()
    cursor = conn.cursor()

    # Table to store book details
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            isbn TEXT UNIQUE NOT NULL,
            total_copies INTEGER NOT NULL,
            available_copies INTEGER NOT NULL
        )
    """)

    # Table to store member (library user) details
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT,
            membership_date TEXT NOT NULL
        )
    """)

    # Table to store issue/return transactions
    # This is the table that drives the "business logic" of the system
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            member_id INTEGER NOT NULL,
            issue_date TEXT NOT NULL,
            due_date TEXT NOT NULL,
            return_date TEXT,
            fine REAL DEFAULT 0,
            FOREIGN KEY (book_id) REFERENCES books (id),
            FOREIGN KEY (member_id) REFERENCES members (id)
        )
    """)

    conn.commit()
    conn.close()
