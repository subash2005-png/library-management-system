"""
models.py
---------
Defines simple data classes (OOP) representing the core entities
of the system: Book and Member.

These classes don't talk to the database directly — they just
represent the data in a clean, structured way. The Library class
(in library.py) is responsible for database operations. This is
a basic form of separation of concerns: data representation vs.
business logic.
"""


class Book:
    def __init__(self, id, title, author, isbn, total_copies, available_copies):
        self.id = id
        self.title = title
        self.author = author
        self.isbn = isbn
        self.total_copies = total_copies
        self.available_copies = available_copies

    def __str__(self):
        return (f"[{self.id}] '{self.title}' by {self.author} "
                f"(ISBN: {self.isbn}) - Available: {self.available_copies}/{self.total_copies}")


class Member:
    def __init__(self, id, name, email, phone, membership_date):
        self.id = id
        self.name = name
        self.email = email
        self.phone = phone
        self.membership_date = membership_date

    def __str__(self):
        return f"[{self.id}] {self.name} ({self.email}) - Joined: {self.membership_date}"
